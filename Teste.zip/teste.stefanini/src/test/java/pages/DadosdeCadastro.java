package pages;

import org.openqa.selenium.By;

import metodos.Metodos;

public class DadosdeCadastro {
	
	Metodos metodos = new Metodos();
	
	By nomeUsuario = By.id("name");
	By emailUsuario = By.id("email");
	By senhaUsuario = By.id("password");
	By cadastrar = By.id("register");
	By excluir = By.id("removeUser1");
	
	public void dadosUsuario (String nome, String email, String senha) {
		
		metodos.preencher(nomeUsuario, nome);
		metodos.preencher(emailUsuario, email);
		metodos.preencher(senhaUsuario, senha);
		
	}
	
	public void botaoCadastrar() {
		metodos.clicar(cadastrar);
		
	}
	
	public void botaoExcluir() {
		metodos.clicar(excluir);
		
	}

}
