package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import metodos.Metodos;
import pages.DadosdeCadastro;

public class CadastroUsu�rio {
	
	Metodos metodos = new Metodos();
	DadosdeCadastro dcad = new DadosdeCadastro();
	
	@Given("que eu esteja na area de cadastro de usuarios {string}")
	public void que_eu_esteja_na_area_de_cadastro_de_usuarios(String site) {
	   metodos.abrirNavegador(site);
	}

	@Given("eu preencher os dados")
	public void eu_preencher_os_dados() {
		dcad.dadosUsuario("Jo�o Pedro", "teste@teste.com.br", "78965412");
			   
	}

	@When("eu clicar no botao Cadastrar")
	public void eu_clicar_no_botao_cadastrar() {
	    dcad.botaoCadastrar();
		
	}

	@Then("os dados do usuario cadastrado aparecerao na tela de resultados")
	public void os_dados_do_usuario_cadastrado_aparecerao_na_tela_de_resultados() {
	   metodos.screenShot("Todo os dados preenchidos"); 
	}
	
	@Given("eu nao preencher os dados")
	public void eu_nao_preencher_os_dados() {
	    dcad.dadosUsuario("", "", "");
	}
	@Then("valido que aparece a mensagem que os campos sao obrigatorios")
	public void valido_que_aparece_a_mensagem_que_os_campos_sao_obrigatorios() {
	   metodos.screenShot("Todos os dados em Branco");
	}
	
	@Given("eu preencher o campo nome sem sobrenome")
	public void eu_preencher_o_campo_nome_sem_sobrenome() {
		dcad.dadosUsuario("Jo�o", "teste@teste.com.br", "78965412");
	}

	@Then("valido que aparece a mensagem que o nome tem que ser completo")
	public void valido_que_aparece_a_mensagem_que_o_nome_tem_que_ser_completo() {
		metodos.screenShot("Campo nome sem sobrenome");
		
	}
	
	@Given("eu preencher o campo email com dados invalidos")
	public void eu_preencher_o_campo_email_com_dados_invalidos() {
		dcad.dadosUsuario("Jo�o Pedro", "testeteste.com.br", "78965412");
		
	}

	@Then("valido que aparece a mensagem que o email tem que ser um valido")
	public void valido_que_aparece_a_mensagem_que_o_email_tem_que_ser_um_valido() {
		metodos.screenShot("Campo email invalido");
	}
	
	@Given("eu preencher o campo senha com menos digitos")
	public void eu_preencher_o_campo_senha_com_menos_digitos() {
		dcad.dadosUsuario("Jo�o Pedro", "teste@teste.com.br", "789654");
		
	}

	@Then("valido que aparece a mensagem que a senha deve conter oito digitos")
	public void valido_que_aparece_a_mensagem_que_a_senha_deve_conter_oito_digitos() {
		metodos.screenShot("Campo senha com menos digitos");
		
	}
	
	//excluir
	@Given("eu tenha preenchido os dados corretamente")
	public void eu_tenha_preenchido_os_dados_corretamente() {
		dcad.dadosUsuario("Jo�o Pedro", "teste@teste.com.br", "78965412");
		
	}

	@When("os dados do usuario cadastrado aparecerao na tela")
	public void os_dados_do_usuario_cadastrado_aparecerao_na_tela() {
		metodos.screenShot("Dados usuario antes da exclusao");
	}

	@When("cadatrar novo usuario")
	public void cadatrar_novo_usuario() {
		dcad.dadosUsuario("Roberto Carlos", "rcarlos@somlivre.com.br", "56987412");
		
	}
	
	@When("eu clicar novamente no cadastrar")
	public void eu_clicar_novamente_no_cadastrar() {
		dcad.botaoCadastrar();
		
	}

	@When("os dados do novo usuario cadastrado aparecerao na ordem de id na tela")
	public void os_dados_do_novo_usuario_cadastrado_aparecerao_na_ordem_de_id_na_tela() {
		metodos.screenShot("Dados usuario antes da exclusao2");
	}
	
	@When("eu queira apagar os dados cadastrados")
	public void eu_queira_apagar_os_dados_cadastrados() {
	    dcad.botaoExcluir();
	    
	}

	@Then("valido que os dados foram excluidos")
	public void valido_que_os_dados_foram_excluidos() {
		metodos.screenShot("Dados usuarios apos a exclusao");
		
	}


}
