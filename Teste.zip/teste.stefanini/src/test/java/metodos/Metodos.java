package metodos;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class Metodos extends Browser {
	
	public void clicar(By elemento) {

		try {
			driver.findElement(elemento).click();

		} catch (Exception e) {
			System.err.println("----------- erro ao clicar ----------" + e.getMessage());
		}

	}

	
	public void preencher(By elemento, String texto) {

		try {

			driver.findElement(elemento).sendKeys(texto);

		} catch (Exception e) {

			System.err.println("----------- erro ao preencher ----------" + e.getMessage());

		}
	}

	
	public void clicarPorTexto(String texto, String tag) {

		try {
			Thread.sleep(3000);
			driver.findElement(By.xpath("//" + tag + "[text()=\"" + texto + "\"]")).click();

		} catch (Exception e) {

			System.err.println("-----------erro ao clicarPorTexto -------" + e.getMessage());
		}
	}

	
	
	public void screenShot(String nome) {
		try {
			Thread.sleep(3000);
			TakesScreenshot scrShot = ((TakesScreenshot) driver);
			File scrFile = scrShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File("./Relatorios Screen/" + nome + ".png");
			FileUtils.copyFile(scrFile, destFile);
			
		} catch (Exception e) {
			System.out.println("----- error no screenShot -----" + " " + e.getMessage());
			
		
		}

	}

	/**
	 * Metodo para validar se dois textos s�o iguais
	 * 
	 * @author amos_
	 * @param elemento
	 * @param textoEsperado
	 * @param passo
	 */

	public void validarTexto(By elemento, String textoEsperado, String passo) {
		try {
			Thread.sleep(3000);
			String textoCapturado = driver.findElement(elemento).getText();
			assertEquals(textoEsperado, textoCapturado);
		} catch (Exception e) {
			System.err.println("-------- error ao validar texto -------" + passo + " " + e.getMessage());
		}

	}

}
